## This file is a workaround for Github issue #24
__version_tuple__ = (1, 2, 47)
__version__ = '.'.join(map(str, __version_tuple__))
