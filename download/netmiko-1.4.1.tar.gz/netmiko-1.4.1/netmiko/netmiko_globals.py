from __future__ import unicode_literals

MAX_BUFFER = 65535
BACKSPACE_CHAR = '\x08'
